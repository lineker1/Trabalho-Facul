package funcoes

fun incremento(num: Int) {
    // num++ // num = num + 1
}

fun main(args: Array<String>) {
    incremento(3)
}