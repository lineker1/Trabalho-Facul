package fundamentos

fun main(args: Array<String>) {
    val raio = 4.5
    print(raio * raio * Math.PI)
}