package fundamentos

/**
 * Só para dizer que o Kotlin suporta o KDoc... :)
 *
 * @param args lista de parâmetros passados por linha de comando
 */
fun main(args: Array<String>) {
    // Comentário de uma linha
    println("Opa")

    /*
      Mais de
      um linha
     */
    println("Sério?")

    /*
     * Mais de
     * um linha
     * com estilo
     */
    println("Legal!")
}