package fundamentos

fun imprimirSoma(a: Int, b: Int) {
    println(a + b)
}

fun main(args: Array<String>) {
    imprimirSoma(4, 5)
}