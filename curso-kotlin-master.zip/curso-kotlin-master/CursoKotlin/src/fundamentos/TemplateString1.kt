package fundamentos

fun main(args: Array<String>) {
    val aprovados = listOf("João", "Maria", "Pedro")
    print("O primeiro colocado foi ${aprovados[0]}.")
}