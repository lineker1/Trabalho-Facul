package fundamentos

fun main(args: Array<String>) {
    val a: Int = 1
    val b = 2 // Tipo inferido

    // a = a + b
    print(a)
}