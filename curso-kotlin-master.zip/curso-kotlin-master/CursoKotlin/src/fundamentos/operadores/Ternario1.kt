package fundamentos.operadores

fun main(args: Array<String>) {
    val nota: Double = 7.2
    val resultado: String = if(nota >= 7) "Aprovado" else "Reprovado"
    println(resultado)
}