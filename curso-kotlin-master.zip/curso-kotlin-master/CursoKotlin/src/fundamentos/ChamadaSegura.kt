package fundamentos

fun main(args: Array<String>) {
    var a: Int? = null // safe call operator
    println(a?.dec())
}