package fundamentos.controles

fun main(args: Array<String>) {
    for(i in 1..10) {
        println(i)
    }
}