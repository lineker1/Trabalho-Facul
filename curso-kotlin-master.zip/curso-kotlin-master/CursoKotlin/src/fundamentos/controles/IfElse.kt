package fundamentos.controles

fun main(args: Array<String>) {
    val nota: Double = 5.3

    if (nota >= 7.0) {
        println("Aprovado!!")
    } else {
        println("Reprovado!!")
    }
}