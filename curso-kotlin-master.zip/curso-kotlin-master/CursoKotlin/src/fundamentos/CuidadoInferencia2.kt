package fundamentos

fun main(args: Array<String>) {
    var a: Double = 1.0
    var b = 2

    a = 2.3

    print(a + b)
}