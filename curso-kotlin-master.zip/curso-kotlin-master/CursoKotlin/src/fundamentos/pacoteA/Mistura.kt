package fundamentos.pacoteA

fun simplesFuncao(texto: String): String {
    return "Texto = $texto"
}

class Coisa(val nome: String)

enum class FaceMoeda { CARA, COROA }