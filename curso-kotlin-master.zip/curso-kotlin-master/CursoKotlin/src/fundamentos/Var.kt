package fundamentos

fun main(args: Array<String>) {
    var a: Int
    var b = 2 // Tipo inferido

    a = 10

    print(a + b)
}