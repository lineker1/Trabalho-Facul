package fundamentos

fun main(args: Array<String>) {
    val bomHumor = false
    print("Hoje estou ${if (bomHumor) "feliz" else "chateado"}.")
}