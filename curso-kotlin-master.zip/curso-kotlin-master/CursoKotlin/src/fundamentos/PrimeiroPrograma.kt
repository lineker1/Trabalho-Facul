package fundamentos

fun main(args: Array<String>) {
    print("Primeiro")
    println(" programa!");
}